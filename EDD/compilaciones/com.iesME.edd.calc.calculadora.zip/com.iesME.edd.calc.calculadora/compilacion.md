<center><h1>Compilaciones<h></center>

#### TO-DO
<p>A partir del código proporcionado, implemente la nueva funcionalidad en la calculadora <b>mayorQue</b>,que indique si el primer argumento que le proporcionamos es mayor que el segundo. El tipo de valor de regreso deberá ser lógico (0 falso, 1 verdadero).
</p>

![Alt text](1_2.png)

![Alt text](1_1.png)

<p>Ejecuta el código desde terminal, muestra todos los pasos que has hecho para obtener ese resultado (compilaciones…)
</p>

![Alt text](2.png)

<p>Ejecuta el código desde el IDE de Netbeans, muestra todos los pasos</p>

![Alt text](3.png)
<p>Sube también el código generado a la tarea
</p>


<p>A partir del proyecto “Calculadora” en Ant, ejecuta los comandos en Ant de “Clean”, “Compile”, “Run” y “Jar”
<p>

* Ant compile y clean
![Alt text](antCompile.png)
* Ant run
![Alt text](antRun.jpeg)

<p>Modifica el comando jar:


* Al ejecutarlo realice antes “compile”

![Alt text](antCompile.png)
![Alt text](ficJAr.png)
![Alt text](javaJAr.png)

* El archivo compilado lo guarde en una carpeta “Jar”

![Alt text](carpetajar.png)
![Alt text](jarjar.png)
<p>