<center><h1>maven</h1></center>

:heavy_check_mark: Haz capturas de imágenes en el que muestres el uso de mvn compile, mvn clean, mvn package y la ejecución de “myhelloMVN”
![Alt text](archivo1.png)

* En el archivo pom.xml se agregó la linea llamada (<b>properties</b>)
![Alt text](pom1.png)
<b>  maven compile</b>

![Alt text](mavenCompile.png)

![Alt text](tree1.png)

<b>maven clean</b>

![Alt text](mavenClean.png)
<b>maven package</b>

![Alt text](mavenpackage.png)

<b>hola Mundo</b>

![Alt text](holaMundo.png)
:heavy_check_mark: A partir del código de la calculadora (de la práctica anterior), haz un proyecto maven en netbeans

   :pencil2: Haz capturas de parte del proceso (puedes hacer alguna captura de como inicias el proyecto más una breve explicación)

![Alt text](MNVarchivo.png)
![Alt text](MVNarchivos.png)
 :pencil2: Usa mvn compile, mvn clean, mvn package y su ejecución (hazlo con el comando java….)

 ![Alt text](MVNcompile.png)




![Alt text](mvnclean2.png)

* Empaquetamos el proyecto en un formato específico. 
![Alt text](mvnpackage2.png)



![alt text](tree2.png)

* Después de hacer el comando tree. Seguimos la ruta para compilar.
![alt text](javaejercicio2.png)